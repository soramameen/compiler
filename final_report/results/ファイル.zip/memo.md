09b23549@S006:~/exp-c/network$ ./client_for_nichi
> %Q
Connection closed by server.
09b23549@S006:~/exp-c/network$ ./client_for_nichi
> %R sample.csv
Success: Loaded 2886 profiles from sample.csv
> %P 3
ID: 5100046
Name: The Bridge
Birthday: 1845-11-02
Address: 14 Seafield Road Longman Inverness
Other: SEN Unit 2.0 Open
ID: 5100127
Name: Bower Primary School
Birthday: 1908-01-19
Address: Bowermadden Bower Caithness
Other: 01955 641225 Primary 25 2.6 Open
ID: 5100224
Name: Canisbay Primary School
Birthday: 1928-07-05
Address: Canisbay Wick
Other: 01955 611337 Primary 56 3.5 Open
> %C
2886 profile(s).
> %W sorai.csv
Success: Saved 2886 profiles to sorai.csv
> 

